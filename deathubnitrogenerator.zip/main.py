import os, sys, time
import math
import json
import urllib.request
import urllib.error
import random as rng
import shutil, ctypes

if sys.platform[:3] == "win":
    import msvcrt

CSI = "\x1b["
shades = [231, 231, 255, 254, 253, 252, 251, 250, 248, 245, 242, 239, 236]
ramp = "@%#*+=:-. "
TWO_PI = 6.28

banner = """
██████╗ ███████╗ █████╗ ████████╗██╗  ██╗    ██╗  ██╗██╗   ██╗██████╗
██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██║  ██║    ██║  ██║██║   ██║██╔══██╗
██║  ██║█████╗  ███████║   ██║   ███████║    ███████║██║   ██║██████╔╝
██║  ██║██╔══╝  ██╔══██║   ██║   ██╔══██║    ██╔══██║██║   ██║██╔══██╗
██████╔╝███████╗██║  ██║   ██║   ██║  ██║    ██║  ██║╚██████╔╝██████╔╝
╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝    ╚═╝  ╚═╝ ╚═════╝ ╚═════╝
"""

subtitle = "// Nitro Generator"

menu = (
    ("1", "Giftlinks Generator"),
    ("2", "Giftlinks Checker"),
)

grad_stops = ((255, 255, 255), (0, 0, 0))
grad_min = 45

GIFT_POOL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
OUTPUT_DIR = "Output"
OUTPUT_FILE = "NitroLinks.txt"

GIFT_API = "https://discord.com/api/v10/entitlements/gift-codes/"
GIFT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
GIFT_STATUS = {
    "valid": ("VALID", "38;2;90;210;130"),
    "redeemed": ("REDEEMED", "38;2;220;180;80"),
    "invalid": ("INVALID", "38;2;200;90;90"),
    "error": ("ERROR", "38;2;150;150;150"),
}
CHECK_BUCKET_CAP = 4.0
CHECK_REFILL = 1.0 / 9.0

_win = sys.platform[:3] == "win"


def death_size():
    try:
        w, h = shutil.get_terminal_size()
    except Exception:
        return 80, 24
    if w < 20: w = 20
    if h < 10: h = 10
    return w, h


def deathub_console():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if not _win:
        return
    os.system("")
    try:
        k32 = ctypes.windll.kernel32
        hnd = k32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if k32.GetConsoleMode(hnd, ctypes.byref(mode)):
            k32.SetConsoleMode(hnd, mode.value | 4)
    except Exception:
        pass

    if not _win:
        return
    try:
        u32 = ctypes.windll.user32
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            r = ctypes.wintypes.RECT()
            u32.GetWindowRect(hwnd, ctypes.byref(r))
            dx = (u32.GetSystemMetrics(0) - (r.right - r.left)) // 2
            dy = (u32.GetSystemMetrics(1) - (r.bottom - r.top)) // 2
            u32.SetWindowPos(hwnd, 0, dx, dy, 0, 0, 5)
    except Exception:
        pass


class Flame:
    __slots__ = ("x", "y", "v", "drift", "tail")

    def __init__(s, W, H):
        s.kick(W, H, True)

    def kick(s, W, H, first=False):
        s.x = rng.uniform(0, W - 1 if W > 1 else 1)
        s.drift = rng.uniform(-0.25, 0.25)
        s.v = rng.uniform(14.0, 40.0)
        s.tail = rng.randint(4, 12)
        s.y = rng.uniform(-H if first else -s.tail, -1)

    def move(s, dt, W, H):
        s.y += s.v * dt
        s.x += s.drift * s.v * dt
        if s.y - s.tail > H or s.x < -2 or s.x > W + 2:
            s.kick(W, H)


def flame_stars(W, H):
    total = (W * H) // 90
    if total < 10:
        total = 10
    pool = []
    i = 0
    while i < total:
        pool.append([
            rng.randint(0, W - 1),
            rng.randint(0, H - 1),
            rng.uniform(0, TWO_PI),
            rng.uniform(1.5, 4.0),
        ])
        i += 1
    return pool


def death_text(grid):
    out = []
    for row in grid:
        cur = None
        chunk = []
        for g, sh in row:
            if sh is None:
                if cur is not None:
                    chunk.append(CSI + "0m")
                    cur = None
                chunk.append(g)
                continue
            if sh != cur:
                chunk.append(CSI + "38;5;" + str(sh) + "m")
                cur = sh
            chunk.append(g)
        if cur is not None:
            chunk.append(CSI + "0m")
        out.append("".join(chunk))
    return "\n".join(out)


def flame_render(flames, stars, W, H, t):
    grid = [[(" ", None)] * W for _ in range(H)]

    for st in stars:
        x, y, ph, per = st
        if x >= W or y >= H:
            continue
        if math.sin(t * (TWO_PI / per) + ph) > 0.3:
            grid[y][x] = (".", 240)

    last = len(ramp) - 1
    lastc = len(shades) - 1
    for m in flames:
        cx = int(m.x + 0.5)
        if cx < 0 or cx >= W:
            continue
        d = 0
        while d <= m.tail:
            ry = int(m.y + 0.5) - d
            d += 1
            if ry < 0 or ry >= H:
                continue
            if d == 1:
                grid[ry][cx] = ("@", shades[0])
            else:
                f = (d - 1) / (m.tail if m.tail else 1)
                if f > 1.0:
                    f = 1.0
                ch = ramp[int(f * last)]
                if ch != " ":
                    grid[ry][cx] = (ch, shades[int(f * lastc)])
    return grid


def deathub_enter():
    sys.stdout.write(CSI + "?1049h" + CSI + "2J" + CSI + "H" + CSI + "?25l")
    sys.stdout.flush()


def deathub_restore():
    sys.stdout.write(CSI + "?25h" + CSI + "?1049l")
    sys.stdout.flush()


def deathub_shower(secs):
    W, H = death_size()
    flames = [Flame(W, H) for _ in range(90)]
    stars = flame_stars(W, H)
    pending = 0.0

    deathub_enter()
    t0 = time.time()
    tick = t0
    try:
        while time.time() - t0 < secs:
            now = time.time()
            dt = now - tick
            if dt > 0.05:
                dt = 0.05
            tick = now

            W, H = death_size()
            for m in flames:
                m.move(dt, W, H)

            pending += 22.0 * dt
            while pending >= 1.0 and len(flames) < 400:
                flames.append(Flame(W, H))
                pending -= 1.0

            sys.stdout.write(CSI + "2J" + CSI + "H")
            sys.stdout.write(death_text(flame_render(flames, stars, W, H, now)))
            sys.stdout.flush()
            time.sleep(0.033)
    finally:
        deathub_restore()


def grad_rgb(f):
    if f < 0.0:
        f = 0.0
    if f > 1.0:
        f = 1.0
    n = len(grad_stops) - 1
    p = f * n
    i = int(p)
    if i >= n:
        i = n - 1
    t = p - i
    a = grad_stops[i]
    b = grad_stops[i + 1]
    return (
        a[0] + (b[0] - a[0]) * t,
        a[1] + (b[1] - a[1]) * t,
        a[2] + (b[2] - a[2]) * t,
    )


def grad_fg(f, k=1.0):
    r, g, b = grad_rgb(f)
    r = int(r * k + 0.5)
    g = int(g * k + 0.5)
    b = int(b * k + 0.5)
    if r < grad_min: r = grad_min
    if g < grad_min: g = grad_min
    if b < grad_min: b = grad_min
    return CSI + "38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"


def grad_text(s, a=0.0, b=1.0, k=1.0):
    n = len(s)
    if n == 0:
        return ""
    out = []
    cur = None
    i = 0
    while i < n:
        col = grad_fg(a + (b - a) * ((i + 0.5) / n), k)
        if col != cur:
            out.append(col)
            cur = col
        out.append(s[i])
        i += 1
    out.append(CSI + "0m")
    return "".join(out)


def grad_art(rows, lo=0.0, hi=0.62, tilt=0.38):
    n = len(rows)
    out = []
    i = 0
    while i < n:
        k = i / (n - 1) if n > 1 else 0.0
        a = lo + (hi - lo) * k
        out.append(grad_text(rows[i], a, a + tilt))
        i += 1
    return out


def death_menu_width(row):
    return len("    ".join(n + "." + t for n, t in row))


def death_menu_rows(W):
    full = [list(menu)]
    half = [list(menu[i:i + 2]) for i in range(0, len(menu), 2)]
    single = [[m] for m in menu]
    for cand in (full, half, single):
        if max(death_menu_width(r) for r in cand) <= W:
            return cand
    return single


def death_menu_line(row, a=0.0, b=1.0):
    plain = "    ".join(n + "." + t for n, t in row)
    total = len(plain)
    if total == 0:
        return ""
    out = []
    pos = 0
    first = True
    for num, txt in row:
        if not first:
            out.append("    ")
            pos += 4
        first = False
        head = num + "."
        lo = a + (b - a) * (pos / total)
        mid = a + (b - a) * ((pos + len(head)) / total)
        out.append(CSI + "1m" + grad_text(head, lo, mid))
        pos += len(head)
        hi = a + (b - a) * ((pos + len(txt)) / total)
        out.append(grad_text(txt, mid, hi))
        pos += len(txt)
    return "".join(out)


def death_menu(W):
    rows = death_menu_rows(W)
    n = len(rows)
    i = 0
    while i < n:
        a = 0.05 + 0.60 * (i / n)
        b = 0.05 + 0.60 * ((i + 1) / n)
        pad = (W - death_menu_width(rows[i])) // 2
        if pad < 0:
            pad = 0
        print(" " * pad + death_menu_line(rows[i], a, b))
        i += 1


def gift_code(n=16):
    return "".join(rng.choice(GIFT_POOL) for _ in range(n))


def flush_keys():
    if _win:
        try:
            while msvcrt.kbhit():
                msvcrt.getch()
        except Exception:
            pass


def enter_hit():
    if _win:
        try:
            if msvcrt.kbhit():
                return msvcrt.getch() in (b"\r", b"\n")
        except Exception:
            return False
        return False
    try:
        import select
        if select.select([sys.stdin], [], [], 0)[0]:
            sys.stdin.readline()
            return True
    except Exception:
        return False
    return False


def wait_with_stop(secs):
    end = time.time() + secs
    while True:
        left = end - time.time()
        if left <= 0:
            return False
        if enter_hit():
            return True
        time.sleep(0.05 if left > 0.05 else left)


def generate_giftlinks():
    W, _ = death_size()
    print()
    print(grad_text("  Per Link Generation Speed ", 0.05, 0.35) + CSI + "38;2;110;110;110m" + "(1ms - 1000ms, default 100): " + CSI + "0m")
    sys.stdout.flush()
    try:
        raw = input().strip().lower().replace("ms", "").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    delay = 100
    if raw:
        try:
            delay = int(float(raw))
        except ValueError:
            delay = 100
    if delay < 1:
        delay = 1
    if delay > 1000:
        delay = 1000

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    flush_keys()

    sys.stdout.write(CSI + "2J" + CSI + "H")
    sys.stdout.write(grad_text("  Giftlinks Generator", 0.05, 0.55) + "\n")
    sys.stdout.write(
        CSI + "38;2;140;140;140m" + "  Speed " + CSI + "0m"
        + grad_text(str(delay) + "ms", 0.0, 0.3)
        + CSI + "38;2;140;140;140m" + "  |  press " + CSI + "0m"
        + grad_text("ENTER", 0.0, 0.3)
        + CSI + "38;2;140;140;140m" + " to stop" + CSI + "0m\n"
    )
    sys.stdout.write(CSI + "38;2;80;80;80m" + "  " + "-" * (W - 4) + CSI + "0m\n\n")
    sys.stdout.flush()

    links = []
    t0 = time.time()
    step = 0.02
    try:
        while True:
            link = "https://discord.gift/" + gift_code()
            links.append(link)
            sys.stdout.write(
                CSI + "38;2;100;100;100m" + "{:>6}".format(len(links)) + CSI + "0m"
                + "  " + grad_text(link, 0.0, 0.45, 0.85) + "\n"
            )
            sys.stdout.flush()

            remaining = delay / 1000.0
            stop = False
            while remaining > 0:
                if enter_hit():
                    stop = True
                    break
                time.sleep(step if remaining > step else remaining)
                remaining -= step
            if stop:
                break
    except KeyboardInterrupt:
        pass
    flush_keys()

    path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(links) + ("\n" if links else ""))
    except Exception as e:
        sys.stdout.write("\n" + CSI + "1m" + CSI + "38;2;200;90;90m" + "  save failed: " + str(e) + CSI + "0m" + "\n")
        sys.stdout.flush()
        return

    elapsed = time.time() - t0
    sys.stdout.write(
        "\n" + grad_text("  saved " + str(len(links)) + " links", 0.05, 0.5)
        + CSI + "38;2;110;110;110m" + "  ->  " + path + "  (" + ("%.1f" % elapsed) + "s)" + CSI + "0m" + "\n"
    )
    sys.stdout.write(CSI + "38;2;110;110;110m" + "  press ENTER to return to the homepage" + CSI + "0m" + "\n")
    sys.stdout.flush()
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        pass


def gift_status(code):
    req = urllib.request.Request(
        GIFT_API + code + "?with_application=false&with_subscription_plan=true",
        headers={
            "User-Agent": GIFT_UA,
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "close",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        if data.get("redeemed", False):
            return "redeemed"
        return "valid"
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return "invalid"
        if e.code == 429:
            try:
                body = json.loads(e.read().decode("utf-8", "replace"))
                wait = float(body.get("retry_after", 1.0))
            except Exception:
                wait = 1.0
            if wait < 0.1:
                wait = 0.1
            if wait > 60.0:
                wait = 60.0
            return ("ratelimit", wait)
        return "error"
    except Exception:
        return "error"


def check_giftlinks():
    path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
    print()
    if not os.path.isfile(path):
        print(CSI + "1m" + CSI + "38;2;200;90;90m" + "  no " + path + " found - generate links first" + CSI + "0m")
        return

    links = []
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if line:
                    links.append(line)
    except Exception as e:
        print(CSI + "1m" + CSI + "38;2;200;90;90m" + "  read failed: " + str(e) + CSI + "0m")
        return
    if not links:
        print(CSI + "1m" + CSI + "38;2;200;90;90m" + "  " + path + " is empty" + CSI + "0m")
        return

    flush_keys()
    sys.stdout.write(CSI + "2J" + CSI + "H")
    W, _ = death_size()
    sys.stdout.write(grad_text("  Giftlinks Checker", 0.05, 0.55) + "\n")
    sys.stdout.write(
        CSI + "38;2;140;140;140m" + "  " + str(len(links)) + " links  |  press " + CSI + "0m"
        + grad_text("ENTER", 0.0, 0.3)
        + CSI + "38;2;140;140;140m" + " to stop" + CSI + "0m\n"
    )
    sys.stdout.write(CSI + "38;2;80;80;80m" + "  " + "-" * (W - 4) + CSI + "0m\n\n")
    sys.stdout.flush()

    counts = {"valid": 0, "redeemed": 0, "invalid": 0, "error": 0}
    checked = 0
    stopped = False
    tokens = CHECK_BUCKET_CAP
    refill = CHECK_REFILL
    last = time.time()
    t0 = time.time()
    try:
        for i, link in enumerate(links, 1):
            if enter_hit():
                stopped = True
                break
            now = time.time()
            tokens = min(CHECK_BUCKET_CAP, tokens + (now - last) * refill)
            last = now
            if tokens < 1.0:
                end = time.time() + (1.0 - tokens) / refill
                while True:
                    left = end - time.time()
                    if left <= 0:
                        break
                    if enter_hit():
                        stopped = True
                        break
                    sys.stdout.write(
                        "\r  " + CSI + "38;2;110;110;110m" + "next link in " + str(int(left) + 1) + "s"
                        + CSI + "0m" + " " * 8
                    )
                    sys.stdout.flush()
                    time.sleep(0.1 if left > 0.1 else left)
                if stopped:
                    break
                sys.stdout.write("\r" + " " * 32 + "\r")
                sys.stdout.flush()
                tokens = 0.0
                last = time.time()
            else:
                tokens -= 1.0
            code = link.rstrip("/").split("/")[-1].split("?")[0]
            status = "error"
            tries = 0
            while True:
                status = gift_status(code)
                if not (isinstance(status, tuple) and status[0] == "ratelimit"):
                    break
                wait = status[1]
                sys.stdout.write(
                    "\r  " + CSI + "1m" + CSI + "38;2;220;180;80m" + "rate limited - waiting "
                    + ("%.1f" % wait) + "s" + CSI + "0m" + " " * 8
                )
                sys.stdout.flush()
                if wait_with_stop(wait + 0.3):
                    stopped = True
                    break
                if wait > 1.0:
                    refill = max(1.0 / 30.0, min(refill, 1.0 / wait))
                tokens = 0.0
                last = time.time()
                tries += 1
                if tries >= 3:
                    status = "error"
                    break
            if tries:
                sys.stdout.write("\r" + " " * min(W - 1, 48) + "\r")
                sys.stdout.flush()
            if stopped:
                break
            if isinstance(status, tuple):
                status = "error"
            checked += 1
            counts[status] += 1
            label, col = GIFT_STATUS[status]
            sys.stdout.write(
                CSI + "38;2;100;100;100m" + "{:>6}".format(i) + CSI + "0m"
                + "  " + grad_text(link, 0.0, 0.45, 0.85)
                + "  " + CSI + "1m" + CSI + col + "m" + label + CSI + "0m" + "\n"
            )
            sys.stdout.flush()
    except KeyboardInterrupt:
        stopped = True
    flush_keys()

    elapsed = time.time() - t0
    head = "  stopped after " if stopped else "  checked "
    sys.stdout.write("\n" + grad_text(head + str(checked) + " links", 0.05, 0.5))
    for key in ("valid", "redeemed", "invalid", "error"):
        label, col = GIFT_STATUS[key]
        sys.stdout.write("  " + CSI + col + "m" + label.lower() + " " + str(counts[key]) + CSI + "0m")
    sys.stdout.write(CSI + "38;2;110;110;110m" + "  (" + ("%.1f" % elapsed) + "s)" + CSI + "0m\n")
    sys.stdout.write(CSI + "38;2;110;110;110m" + "  press ENTER to return to the homepage" + CSI + "0m" + "\n")
    sys.stdout.flush()
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        pass


def deathub_draw():
    sys.stdout.write(CSI + "2J" + CSI + "H")
    W, _ = death_size()
    art = banner.strip().split("\n")
    wide = max(len(x) for x in art)
    pad = (W - wide) // 2
    if pad < 0:
        pad = 0
    print()
    for line in grad_art(art):
        print(" " * pad + line)
        sys.stdout.flush()
        time.sleep(0.03)
    print()
    sub_pad = (W - len(subtitle)) // 2
    if sub_pad < 0:
        sub_pad = 0
    print(" " * sub_pad + grad_text(subtitle, 0.34, 0.78, 0.8))
    print()
    death_menu(W)
    print()


def deathub_home():
    deathub_draw()
    while True:
        try:
            sys.stdout.write(grad_fg(0.0) + "Death " + CSI + "0m" + CSI + "38;2;125;125;125m" + "> " + CSI + "0m")
            sys.stdout.flush()
            cmd = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if cmd in ("exit", "quit", "q"):
            break
        if not cmd:
            continue
        if cmd == "1":
            generate_giftlinks()
            deathub_draw()
            continue
        if cmd == "2":
            check_giftlinks()
            deathub_draw()
            continue
        print(CSI + "1m" + CSI + "38;2;190;190;190m" + "  > unknown option" + CSI + "0m")


def main():
    deathub_console()
    try:
        deathub_shower(1)
    except KeyboardInterrupt:
        deathub_restore()
    deathub_home()


if __name__ == "__main__":
    main()
