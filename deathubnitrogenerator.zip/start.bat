@echo off
setlocal enabledelayedexpansion
title DEATH HUB
cd /d "%~dp0"

if not exist "main.py" (
    echo Error: main.py not found!
    pause
    exit /b 1
)

set "PYTHON_CMD="
python --version >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=python"

if not defined PYTHON_CMD (
    py --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)

if not defined PYTHON_CMD (
    echo   Python is not installed on this PC.
    echo.
    set /p "INSTALL_CHOICE=Do you want to install Python now? (Y/N): "
    if /i "!INSTALL_CHOICE!"=="Y" (
        winget --version >nul 2>&1
        if errorlevel 1 (
            echo.
            echo winget is not available.
            echo     Please install Python manually from https://python.org
            pause
            exit /b 1
        )
        echo.
        echo [*] Downloading and installing Python 3.12, please wait...
        winget install --id Python.Python.3.12 -e --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
        if errorlevel 1 (
            echo Python installation failed.
            echo     Please install Python manually from https://python.org
            pause
            exit /b 1
        )
        echo.
        echo   Python installed successfully!
        echo.
        echo   Please close this window and run
        echo   start.bat again to launch the program.
        echo.
        pause
        exit /b 0
    ) else (
        echo.
        echo Python is required to run this program.
        pause
        exit /b 1
    )
)

%PYTHON_CMD% main.py
if errorlevel 1 (
    echo.
    echo Something went wrong while running main.py.
    pause
)
